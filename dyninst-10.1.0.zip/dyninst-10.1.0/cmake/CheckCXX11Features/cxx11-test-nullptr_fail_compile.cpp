int main(void)
{
	int i = nullptr;

	return 1;
}
